
Project IGI
README file
24/11/2000
Version 1.1

Part I - things you should know
Part II - technical issues
Appendix A - Graphics Cards / Chipset guide

++++++++++++++++++++++++++++++++++++++++++++++++++++++
*** PART I - THINGS YOU SHOULD KNOW - READ THIS!!! ***
++++++++++++++++++++++++++++++++++++++++++++++++++++++

Graphics Cards
1)  When using Intel i810 etc cards you may need more System Ram than the minimum 64Mb.
2) The ATI Rage Pro 8MB may not work well in D3D with currently available drivers.
3) Some users of the Permedia 2 chipset may experience transparency problems.
4) ALT+TAB may not work properly in full screen mode


Performance
Use the performance slider (under graphics options) to increase performance at the expense of graphical quality.


Please read through the DirectX 7.0a section of this document. This section has information that is vital to successfully running Project IGI on your system.

* DIRECTX 7.0a *

The game uses Microsoft's DirectX 7.0a or later.  In order for you to play the game, you must have DX7.0a-compliant drivers for your video card and sound card. Please note that although DirectX 7.0a is installed with the game, your video and sound card drivers will not be upgraded to DirectX 7.0a or later drivers. You will need to obtain the latest DX7.0a drivers from your card manufacturer.

In Part II of this document you will find extensive documentation about DirectX, should you find it relevant.

* MEMORY AND PERFORMANCE *

While the game will run fine in 64 Mb of RAM, your playing experience will be smoother the more memory you have.

Regardless of how much memory you have, you can maximize your available memory and increase the overall performance of the game engine by doing the following:
* Closing any open windows.
* Shutting down all other programs, including menu-bar programs like ICQ.
* Defragmenting your hard drive.

You can also change certain settings from within the game, to improve your frame rate. Use the Performance Level slider in the Main Menu / Configuration / Graphics menu screen.

* PRIMARY AND SECONDARY 3D GRAPHIC CARDS *

If you have more than one 3D graphic card in your system, you may choose between them by using the Render Device list box in the Main Menu / Configuration / Graphics menu screen.
 
* KNOWN PROBLEMS *

Eidos Interactive is committed to providing customer support for our games on a continuing basis. In that spirit, there may be a patch for the game forthcoming; visit the Eidos website for more information:

http://www.eidosinteractive.com/


*** PART II - TECHNICAL ISSUES ***

* TROUBLESHOOTING ISSUES *

Installation/Setup
CD-ROM Problems
Crashes and Lock-Ups 
AutoPlay Issues
DirectX-Related Questions
Contacting Technical Support

* INSTALLATION/SETUP *

* What are the System Requirements for Project IGI?
* Preparing Your Hard Drive
* Installing Project IGI
* Starting/Loading Project IGI
* Uninstalling Project IGI
 
WHAT ARE THE SYSTEM REQUIREMENTS FOR PROJECT IGI? 

The minimum system requirements are as follows:
	
COMPUTER
	 IBM PC or 100% compatible
OPERATING SYSTEM
	Microsoft Windows 95/98/ME/2000
CPU
	Pentium II 300 MHz.
RAM
	64 Mb
GRAPHICS
	100% DirectX 7.0a or later-compatible 3d Accelerated Video Card
SOUND
	DirectX 7.0a or later compliant sound card
CD-ROM
	Quad-speed (4x) CD-ROM drive
HARD DRIVE
	500 MB uncompressed hard drive space
INPUT DEVICES
	100% Windows 95/98/ME/2000 compatible mouse and keyboard

The recommended system specs are as follows:
CPU
	AMD Athlon or Intel Pentium III processor
RAM
	128 MB RAM
GRAPHICS
	16 Mb 3D Card -100% DirectX 7.0a or later-compatible
CD-ROM
	Eight-speed (8x) CD-ROM drive or faster

PREPARING YOUR HARD DRIVE

To ensure that your installation is trouble free, you should check to see that your hard drive and file system are both tuned for optimum performance. Windows 95/98/ME/2000 comes with two utility programs that find and fix any errors and optimize your hard drive's performance. The first of these programs is called scandisk. Scandisk will check your hard drive for problems and can fix any that it finds. You can run scandisk by clicking on the START button from the Windows 95/98/ME/2000 Taskbar, followed by Programs, then Accessories, then System Tools, and finally scandisk.

Once scandisk has finished running, you should next optimize your hard drive's performance by running a program called Disk Defragmenter. You can run Disk Defragmenter by clicking on the START button from the Windows 95/98/ME/2000 desktop, followed by Programs, then Accessories, then System Tools, and finally Disk Defragmenter.

INSTALLING PROJECT IGI

Installing Project IGI is easy. Simply insert the CD into your CD-ROM drive. After a few seconds, the Launch Panel will appear.

This program will guide you through the remaining process via onscreen prompts. If at any time you are instructed to restart your computer, do so.

In the event the Launch Panel does not appear when you insert the CD:

Double-click on the MY COMPUTER icon, then double-click on the CD-ROM icon, and lastly double-click on the SETUP.EXE file to bring up the Launch Panel OR:

* Click on the START button.
* Choose Run from the pop-up menu.
* Type d:\setup in the box provided (where d: designates your CD-ROM drive letter).
* Click on the OK button to begin the install program.

You will be prompted to select the path and directory to which you wish to install Project IGI on your hard drive. You may change this if you wish to.

At some point, the Microsoft DirectX 7.0a install prompt will appear if you do not have it on your system already. Please read the on-screen information before selecting an option. You may either choose to install or not install at this time. If the installer detects an active version of DirectX 7.0a on your system, we encourage you to not reinstall DirectX. If the installer does not detect DirectX 7.0a, you must install it before you are able to play (please refer to the next section of this guide before proceeding).

STARTING/LOADING PROJECT IGI

Once the install has finished and you have opted to run the game, the Launch Panel will appear on the screen. Click on the Run button to start the game. 

You may also:
* Click on the Uninstall button to uninstall Project IGI.
* Click on the View Readme button to view the readme file. 
* Click on Ok to play Project IGI.
* Click on the Exit button to exit the Launch Panel.

If you are going to play Project IGI at a later time insert the CD into the CD-ROM drive. After a few seconds, the Launch panel should appear on the screen via the AutoPlay feature. Now click on the Run button to start the game. There is also a button present to Exit. 
 
In the event the AutoPlay feature does not work, you may click on the My Computer icon and then click on the CD-ROM icon to bring up the Launch Panel 

OR

* Click on the START button.
* Choose Programs from the pop-up menu.
* Drag your mouse to the right and click on Eidos Interactive from the list.
* Drag your mouse to the right and click on Project IGI from the list.
* Click on Play Project IGI from the ensuing pop-up menu.

UNINSTALLING PROJECT IGI

If you need to UNINSTALL Project IGI, you may do any of the following three things: 

Insert the Project IGI CD into the CD-ROM drive to activate the AutoPlay feature. This will bring up the Launch Panel. Click on the Uninstall button, then click on the Yes button from the ensuing pop-up panel to uninstall the program.
			
OR

* Click on the START button.
* Choose Programs from the pop-up menu.
* Drag your mouse to the right and click on Eidos Interactive from the list.
* Drag your mouse to the right and click on Project IGI from the list.
* Click on Remove Project IGI from the ensuing pop-up menu and follow the onscreen instructions.

OR

Go to the CONTROL PANEL and choose ADD/REMOVE PROGRAMS. Click on Project IGI from the pop-up panel to follow, select the Add/Remove button, and follow the onscreen prompts.

* CD-ROM PROBLEMS *

Project IGI requires at least a Quad-Speed CD-ROM drive with 32-bit Windows 95/98/ME/2000 drivers.

I receive a "xxxxxx.xxx not found" error message when installing or running Project IGI.

This error message is usually the result of your computer using MS-DOS (16 bit) drivers instead of Windows 95 (32 bit) drivers for your CD-ROM drive. You can easily check to see if this is causing problems by opening the CONTROL PANEL (either click on the "My Computer" icon or click on the START button followed by "Settings," then "Control Panel"). In the Control Panel window, double-click on the "System" icon then click on the "Performance" tab. You should now see a summary of the performance status of your computer. One of the lines should say "File System: 32-bit" and the last line should say "Your system is configured for optimal performance." If you see a message saying "Drive X is using MS-DOS compatibility mode," then you will need to contact your system vendor to obtain and install 32-bit drivers for your CD-ROM drive.

The Game AUTOPLAYS multiple times

Some 24x CD ROM drives cause Project IGI to AutoPlay multiple times, which also may result in lack of control within the game. To remedy this problem click on the CD ROM properties in the System Properties panel and under settings turn off Auto Notification.

* CRASHES AND LOCK-UPS *

* When I start Project IGI, my mouse cursor disappears and my computer locks-up.
Chances are your installed audio card drivers are not compatible with DirectX. The only solution is to get a DirectX 7.0a or later-compatible driver from your audio card manufacturer.

* When I start Project IGI, I receive the following error message:
"The application Project IGI.exe referenced memory at  address xxxx:xxxx that can't be read from."

Chances are your installed video card drivers are not compatible with DirectX. The only solution is to get a DirectX 7.0a or later-compatible driver from your video card manufacturer.

* The Installer keeps stopping when a certain percentage is complete, so I can't install Project IGI.

There are three likely causes:

1) You may have run out of free space on your hard drive. Please remove unwanted programs to free up additional space for the game, and then reinstall Project IGI.
2) Files are possibly being copied to a corrupted area of your hard drive. If this is so, you'll need to run the scandisk program and make sure to use the Thorough option (see previous). After scandisk has finished running and has informed you that your drive is free of errors, try to re-install. 
3) There may be dirt or fingerprints on the CD-ROM disc itself. Examine the bottom of the disc; if you see any fingerprints or dirt, carefully clean the disc using a clean, soft, lint-free cloth by wiping from the center of the disc (near the hole) towards the outer edge in a straight line.

* Project IGI is crashing to the desktop with no error messages.

This problem can be caused by several different things. Here's a list of the most common culprits associated with these crashes:

1) Make sure the CD-ROM is clean (check for both scratches and smudges on the reading surface of the CD). 
2) Make sure the game has been installed properly. 
3) Make sure DirectX 7.0a or later has been installed properly. 
4) Make sure you have the latest Windows 95/98/ME/2000 drivers for your video card and that they are DirectX 7.0a or later-compatible. 
5) Make sure you have the latest Windows 95/98/ME/2000 drivers for your sound card and that they are DirectX 7.0a or later-compatible. 
6) Make sure Virtual Memory is enabled on your system. 
7) Run scandisk. 
8) Run Disk Defragmenter. 
9) Clean out old temp (.TMP) files from the C:\WINDOWS\TEMP or C:\WIN95\TEMP directory on your hard drive (from Windows Explorer). 
10) Make sure you do not have any Anti-Virus utilities (like Norton's AntiVirus) running resident prior to playing Project IGI.
11) Make sure you do not have any 3rd party Windows 95/98/ME/2000 memory management utilities (like QuarterDeck's QEMM 8.0 for Windows 95) running resident prior to playing Project IGI.
12) Make sure you do not have any 3rd party Windows 95/98/ME/2000 disk caching utilities running resident prior to playing Project IGI. 
13) Make sure you do not have Norton's Crash Protector running resident prior to playing Project IGI. 
14) Try uninstalling and then reinstalling the game. 
15)	Try exiting the game, rebooting your machine, and re-entering the game.

Note that if your system crashes to the desktop while playing Project IGI, you should probably reboot your computer before starting a new play session. Otherwise, DirectDraw or DirectSound may be in a locked state, and the game will be unable to use your sound or video hardware.

* AUTOPLAY ISSUES *

Why doesn't the AutoPlay feature come up when I insert the Project IGI CD into the CD-ROM drive?

This is usually a configuration issue. There are many different ways to enable the AutoPlay functions of Windows 95/98. The standard method is described below: 

1)	Enter the Windows 95/98/ME/2000 CONTROL PANEL from the desktop by clicking on the START button, followed by SETTINGS, and then CONTROL PANEL.
2)	Double-click the icon labeled SYSTEM, usually located alphabetically towards the bottom of the Control Panel window, to bring up the System Properties panel.
3)	Click on the tab at the top labeled Device Manager and when the new panel appears, locate the section labeled CD-ROM and click the PLUS (+) sign in front of it. (If there is a minus sign in front, don't click it.) 
4)	Now double-click the CD-ROM drive revealed and the CD-ROM Properties panel will appear.
5)	Click on the Settings tab at the top. 
6)	Towards the middle of the panel, you should see a few checkboxes within the Options section. At the bottom of that section, you should see a checkbox labeled Auto insert notification. 
7)	Make sure there is a check mark in the box provided and click on the OK button to complete the process. 

* DIRECTX-RELATED QUESTIONS *

* What is DirectX and do I need it to run Project IGI?
* How do I install DirectX?
* How do I know which version of DirectX I have? Will it run with an older version? And if I do, indeed, have an older version of DirectX, where can I get the latest one?
* How do I manually install the DirectX drivers?
* Help! Project IGI has hosed my system, and I suspect that DirectX is the culprit. How can I restore my original drivers?
* Ahh! I cannot use DirectX on my computer! Is there any other way to run Project IGI?

* What is DirectX and do I need it to run Project IGI?

DirectX is a Microsoft product that allows software and hardware developers to utilize Windows 95/98/ME/2000 to its best potential. Video card and sound card manufacturers need to develop special drivers for their cards that work directly with it. Most already have done so.
Project IGI, in part, uses DirectDraw, DirectInput and Direct3D, components of DirectX. If you have DirectDraw or Direct3D drivers installed on your system, or if you installed the DirectX 7.0a drivers that came with our program and they are incompatible with your video card, you should contact either the vendor of your system or the manufacturer of the video card for their most recent drivers. Video card manufacturers, in particular, generally update their drivers every 2-3 months or so. Depending on the card you have and who produces it, there is a good chance there will be new drivers available. If you do not already have Internet access, we highly recommend you get it since most driver updates are most easily accessible on the home pages of the various hardware manufacturers.
Project IGI also uses DirectSound as well as many other new sound features made available in DirectX7.0a. Once again, we recommend contacting the manufacturer of the card for the latest 100% Windows 95/98/ME/2000 DirectX 7.0a-compatible drivers to ensure optimum performance.
	
* How do I install DirectX?
Microsoft's DirectX 7.0a is included with the Project IGI installer. You will be given the option to install it through a pop-up panel. Click on the appropriate button to install it. If you forget, you may install it at a later time. See the section entitled 'Direct X Manual Installation' below for instructions to do this.

* How do I know which version of DirectX I have? Will it run with an older version? And if I do, indeed, have an older version of DirectX, where can I get the latest one?
The Project IGI installer will do its best to autodetect which version of DirectX currently resides on your system, and then prompt you for any necessary changes. DirectX 7.0a is the latest version of DirectX. This is the version that comes with Project IGI and was thoroughly tested with it. Project IGI REQUIRES DirectX 7.0a or later to play. You cannot play if you have an older version installed.
	
* How do I manually install the DirectX drivers?
If at any time, you want to manually install Microsoft's DirectX 7.0a or later drivers, follow the steps listed below: 

1) Go to Windows Explorer (click on the START button then select PROGRAMS and then WINDOWS EXPLORER at the bottom of the menu). 
2) Place the Project IGI CD into your CD-ROM drive (if the AUTORUN feature comes up, simply select the Explore CD button to return to Windows Explorer. Then skip 3) ). 
3) Open up your CD-ROM drive (generally D:\) and locate the DXSetup folder. 
4) Locate the DXSETUP.EXE file and double-click on it to begin the DirectX manual installation. 
5) A panel will eventually appear (it may take a few seconds) in the upper left-hand corner of the screen labeled DirectX Setup.
6) Click on the ReInstall DirectX button. The setup process will now commence. If the following message appears: 
"Setup has detected display drivers that have not been tested with DirectX. To get the best game performance, setup can replace your existing drivers. Do you want setup to replace the drivers?" 
Make sure you select the NO button, so you do not overwrite or potentially corrupt your native display drivers. (Note, however, that if problems persist after the installation, you may want to repeat steps 1 through 6 and select YES to this option instead. Remember: you have the option to restore your original drivers later if things go awry.)
7) You will finally be asked to reboot your machine. Select the YES button to restart and initialize the new drivers. 

* Help! Project IGI has caused my system to become unstable, and I suspect that DirectX is the culprit. How can I restore my original drivers? 
DirectX has become the new standard in Windows 95/98/ME/2000 application development. Nearly all high-performance software will be geared around this technology, so we do not normally recommend that customers attempt to alter its installation on their system. Unfortunately, there are some systems or hardware devices that just don't work with DirectX yet, and installing DirectX on these systems might cause driver-related problems. YOU CANNOT REMOVE DIRECTX FROM YOUR SYSTEM, but you can restore the original audio and video drivers which the installation of DirectX will have replaced. 

If you currently have DirectX 7.0a or later either installed by Project IGI or previously installed, you should be able to restore the original drivers by going to the ADD/REMOVE PROGRAMS section in the Windows 95 CONTROL PANEL (please refer to the section above entitled DirectX Version for instructions on how to get there).

If you enter the Windows 95/98/ME/2000 CONTROL PANEL and click on the ADD/REMOVE PROGRAMS icon, you should see a list of all of the programs that are registered with Windows 95/98/ME/2000 in the Add/Remove Programs Properties panel.

If you see a listing for "DirectX Drivers", double-click it to open the DirectX Setup panel. At the bottom of this panel, there should be a button labeled Restore Display Drivers. Clicking on this button should restore the original video drivers.. After that, click on the other button labeled Restore Audio drivers. Though DirectX will remain on your system, the restoration of the older drivers may then allow you to run the program. If not, you may want to consider contacting your system vendor for 100% DirectX-compatible drivers for your video and/or sound cards OR visit the web site of the respective hardware manufacturer[s].

* Run Without DirectX?
I cannot use DirectX on my computer! Is there any other way to run Project IGI? 
If you do not have DirectX installed on your computer, you WILL NOT be able to run Project IGI.

* CONTACTING TECHNICAL SUPPORT *

If you need technical assistance, please do not hesitate to contact us, after reading the Readme file. 

When contacting us, please be sure to provide us with as much information as possible. Make sure to note the exact type of hardware that you are using in your system, including: your sound card, CD-ROM drive, amount of RAM present, speed and manufacturer of your processor. Also, make sure to include the title and version of the game, and a detailed description of the problem.

TECHNICAL SUPPORT CONTACT DETAILS UK
Address		Unit 2 Holford Way, Birmingham, B6 7AX.
E-Mail		techsupport@eidosinteractive.co.uk
Phone		0121 356 0831
Web		http://www.eidosinteractive.co.uk/support/index.html

TECHNICAL SUPPORT CONTACT DETAILS GERMANY
Web:		http://www.eidoshelpline.de

TECHNICAL SUPPORT CONTACT DETAILS SPAIN
Web:		http://proein.com

TECHNICAL SUPPORT CONTACT DETAILS ITALY
Gioca sul sito 	http://www.ngi.it
Connettiti al sito http://www.leaderspa.it


TECHNICAL SUPPORT CONTACT DETAILS AUSTRALIA
http://www.ozisoft.com/extra/help.asp

Hints and tips will not be given out over the Technical Support line.

When calling, it helps is you have as much information about your machine as possible so please prepare by doing the following in Windows 95/98:-

Click on Start
Click on Run
Type C:\PROGRAM FILES\DIRECTX\SETUP\DXDIAG.EXE (where C: is the drive letter for where Windows is stored - which may differ on your machine) and click on OK Click on the Save Information button and save the file to your computer. When you call our Technical Support line either have this file open or have a printed copy.

Alternatively, you may find help with hardware problems on one of the websites maintained by the supplier, some of which are listed below:

3DFX:				www.3dfx.com
3D labs:			www.3dlabs.com
ATI Technologies:		www.atitech.com
Creative Labs:			www.creaf.com
Diamond Multimedia:		www.diamondmm.com
Hercules:			www.hercules.com
Matrox:				www.matrox.com
nVIDIA:				www.nvidia.com
Rendition:			www.rendition.com
S3:				www.s3.com
STB:				www.stb.com

EIDOS Interactive maintains a web page with links to all major video and audio card manufacturers, which is a good first stop if you are looking to upgrade your drivers. You can reach this page at:

UK:  http://www.eidosinteractive.co.uk/support/index.html
US:  http://www.eidosinteractive.com/support/index.html
AUS: http://www.ozisoft.com/extra/help.asp


Appendix A - Graphics Cards/Chipset Guide
+++++++++++++++++++++++++++++++++++++++++

A good general reference page for all card and driver issues is: http://www.3dfiles.com/drivers/

Cards using NVidia GeForce2 GTS Chipset
---------------------------------------
ELSA GLADIAC Ultra 64MB GeForce2 Ultra
ELSA GLADIAC GeForce2 GTS 32MB
ASUS AGP-V7700 Deluxe GeForce2 GTS
PowerColor PowerGene GTS 2
Creative 3D Blaster Annihilator 2
Hercules 3D Prophet II GeForce2 MX
ASUS AGP-V7700 GeForce2 GTS
ELSA GLADIAC GeForce2 GTS
Hercules 3D Prophet II GTS
Leadtek WinFast GeForce2 GTS

Cards using Nvidia GeForce 256 Chipset
--------------------------------------
Absolute Multi Media Outrageous 3D DDR
ASUS GeForce Deluxe DDR
ASUS GeForce Deluxe SDR
Creative Labs Annihilator Pro DDR
Creative Labs Annihilator SDR
Elsa Erazor X2 DDR
Elsa Erazor X SDR
Gigabyte GA-GF2560 GeForce 256
Guillemot 3D Prophet DDR-DVI DDR
Guillemot 3D Prophet SDR
LeadTek WinFast GeForce 256 DDR
LeadTek WinFast GeForce 256 SDR

Cards using Nvidia RIVA TNT2 Chipset
------------------------------------
Absolute Multimedia RIVA TNT 2 Ultra
ASUS TNT 2
Creative Labs 3D Blaster RIVA TNT2 
Diamond V770 Ultra
Elsa Erazor III (TNT2)
Falcon Northwest Special Edition Xentor 32
Gainward CardEXPERT TNT 2
Gigabyte GA660-A Plus
Guillemot Cougar
Guillemot Phoenix 2
Guillemot Xentor 32
Hercules Dynamite TNT 2
Hercules Dynamite TNT 2 Ultra
LeadTek TNT 2
Skywell Magic TNT 2
Creative Labs 3D Blaster RIVA TNT2 

Cards Using ATI Radeon Chipset
------------------------------
ATI RADEON SDR 32MB
ATI Radeon 32MB DDR
ATI All-In-Wonder RADEON 32MB DDR
ATI Radeon 64MB DDR Guide

Cards using 3dfx Voodoo 5 Chipset
---------------------------------
3dfx Voodoo4 4500
3dfx Voodoo5 5500
3dfx Voodoo5 6000

Cards using 3dfx Voodoo 3 Chipset
---------------------------------
3dfx Voodoo 3 1000
3dfx Voodoo 3 2000 
3dfx Voodoo 3 3000 
3dfx Voodoo 3 3500
Falcon Northwest SE Voodoo 3 3500 TV

Cards using 3dfx Voodoo 2 Chipset
---------------------------------
3dfx Voodoo 2 1000
3dfx Voodoo 2 (12Mb)

Cards using ATI Rage 128 Chipset
--------------------------------
ATI Rage Fury MAXX
ATI Rage Fury Pro
ATI Xpert 2000/Pro
ATI All-In-Wonder 128 PRO 
ATI Rage Magnum

Cards using Matrox Chipset
---------------------------
Matrox Millennium G450
Matrox Millennium G400 
Matrox Millennium G400 MAX
Gigabyte GA-MG400 16MB Matrox MGA G400
Matrox Millenium G450
Matrox Millenium G200


Cards using S3 Savage 4 Chipset
-------------------------------
Diamond Stealth III
Diamond Stealth III Xtreme
A-trend Savage 4


